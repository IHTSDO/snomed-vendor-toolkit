sct-snapshot-rest-api
=====================

Rest API for SNOMED CT Snapshot views, powered by Node.js, Express &amp; MongoDB
